<?php

use SilverStripe\Assets\Image;
use SilverStripe\ORM\DataObject;

class FooterLogo extends DataObject {

    private static $db = [
        'Title' => 'Varchar',
        'Link' => 'Varchar',
        'Sort' => 'Int'
    ];

    private static $has_one = [
        'Image' => Image::class
    ];

    private static $owns = [
        'Image'
    ];

    public function getCMSFields()
    {
        $fields = parent::getCMSFields();
        $fields->removeByName("Sort");
        return $fields;
    }

}